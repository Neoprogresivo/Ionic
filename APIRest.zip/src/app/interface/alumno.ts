export interface Alumno {
    id:string;
    nombre:string;
}
